#ifndef PROJECT_1_PARSERHELPER_H
#define PROJECT_1_PARSERHELPER_H

class ParserHelper
{
private:
public:
    ParserHelper();
    ~ParserHelper();

};

#endif //PROJECT_1_PARSERHELPER_H
